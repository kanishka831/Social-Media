

<html>
<title>User Profile</title>

<?php
include("header.php");
?>
<script>
$(document).ready(function(){
  $("#inputSearch").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#usersTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
	
  });
});

function funcUnfollow(e)
{
	var RequestTo = $(e).attr("data-userID");
	$.get("FollowUnfollow.php", {sRequest: 0,sRequestTo: RequestTo}, function(result){
		$(e).closest("td").html(result);
	});
}
function funcFollow(e)
{
	var RequestTo = $(e).attr("data-userID");
	$.get("FollowUnfollow.php", {sRequest: 1,sRequestTo: RequestTo}, function(result){
		$(e).closest("td").html(result);
	});
}
</script>

<body>
<div class="bg-image"></div>
<div class='container-fluid'>
	<div class='row'>
		<div class='col-sm-4 offset-sm-4 jumbotron bg-text' style='overflow: scroll;'>
			<input type='text' placeholder='Search...' id='inputSearch' class='form-control'>
			<table id='usersTable' class='table table-sm' >
			<?php
			$query="SELECT u.id,u.profilePic,u.username,IFNULL(fl.RequestStatus,0) as RequestStatus FROM usersinfo u LEFT JOIN friendslist fl ON u.id=fl.RequestTo WHERE u.id!=".$_SESSION['UserID'];
			$result=mysqli_query($con,$query);
			$tr;
			while($arr=mysqli_fetch_array($result))
			{
				$tr="<tr>
						<td><img src='".$arr['profilePic']."' class='rounded-circle' style='width:60px;height:60px;'>  ".$arr['username']."
						</td>
						<td style='float:right;' class='td-follow-unfollow-btn'>";
					if($arr['RequestStatus']==0)
					{
						$tr.="<input type='button' class='btn btn-primary' value='Follow' onclick='return funcFollow(this);' data-userID='".$arr['id']."'>";
					}
					else
					{
						$tr.="<input type='button' class='btn btn-light' value='Following' onclick='return funcUnfollow(this);' data-userID='".$arr['id']."'>";
					}
						$tr.="</td>
					</tr>";
					
					echo $tr;
			}
			?>
			</table>
		</div>
	</div>

	<?php
		include("footer.php");
	?>
</div>


</body>
</html>

