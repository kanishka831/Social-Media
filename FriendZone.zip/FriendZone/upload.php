

<!DOCTYPE html>
<html>
<?php
include("header.php");
?>
<body>
<?php

if(isset($_POST['submit']))
{
	
	$fileName=$_FILES['fileToUpload']["name"];
	$fileType=$_FILES['fileToUpload']["type"];
	$fileSize=$_FILES['fileToUpload']["size"];
	$fileTemp=$_FILES['fileToUpload']["tmp_name"];
	$fileError=$_FILES['fileToUpload']["error"];
	$postType=$_POST['postType'];
	if($fileError==0)
	{
		if($postType==1)
		{
			$dir="UserProfiles/".$fileName;
			move_uploaded_file($fileTemp,$dir);
			$query="UPDATE usersinfo SET profilePic='$dir' WHERE id=".$_SESSION['UserID'];
			mysqli_query($con, $query);
			$msg="User profile upload successfully";
		}
		if($postType==2)
		{
			$dir="Posts/".$fileName;
			$cap=$_POST['caption'];
			move_uploaded_file($fileTemp,$dir);
			$query="INSERT INTO userspost(UserID, PostDir, Caption) VALUES (".$_SESSION['UserID'].",'$dir','$cap')";
			mysqli_query($con, $query);
			$msg="Post upload successfully";
		}
	}
}
?>

<div class='container-fluid'>
	<div class='row'>
		<div class='col-sm-4 offset-sm-4 jumbotron'>
			<form action="upload.php" method="post" enctype="multipart/form-data">
			
				<div class="form-group">
					<label for="uname">Select Type:</label>
					<select name='postType' class='form-control'>
						<option value='-1' >Select</option>
						<option value='1'>User Profile</option>
						<option value='2'>Post</option>
					</select>
				  </div>
  
				<div class="form-group">
				 <label for="exampleFormControlFile1">Select image to upload:</label>
				 <input type="file" class="form-control-file" name="fileToUpload" id="fileToUpload">
			    </div>
				
				
				<div class="form-group">
				  <label>Caption:</label>
				  <textarea class="form-control" rows="5" id="comment" name='caption'></textarea>
				</div>
								
				
			   <input type="submit" value="Upload Image" name="submit" class='form-control btn-primary'>
			   <span style='color:green;'>
			   <?php
			   if(isset($msg))
			   {
					echo $msg;
			   }
			   ?></span>
			</form>
		</div>
	</div>
</div>
<?php
  include("footer.php");
  ?>
  


</body>
</html>
