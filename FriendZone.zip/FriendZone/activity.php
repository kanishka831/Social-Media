<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
	include("header.php");
 ?>
 
</head>
<body>

<div class="bg-image"></div>

<div class="container-fluid">
  <div class="row">
		<div class="col-sm-4 offset-sm-4 jumbotron bg-text" style='overflow: scroll;'>
		</div>
  </div>

  <?php
  include("footer.php");
  ?>
  
</div>

</body>
</html>