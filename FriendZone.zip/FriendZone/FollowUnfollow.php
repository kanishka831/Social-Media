<?php
include("db/connection.php");
session_start();
$sRequest= $_GET['sRequest'];
$sRequestTo= $_GET['sRequestTo'];
$sRequestFrom = $_SESSION['UserID'];

$query="SELECT * FROM friendslist WHERE RequestTo='$sRequestTo' AND RequestFrom='$sRequestFrom'";
$count=mysqli_num_rows(mysqli_query($con,$query));
if($count==0)
{
	$query="INSERT INTO friendslist(RequestTo,RequestFrom,RequestStatus) VALUES($sRequestTo,$sRequestFrom,$sRequest)";
}
else
{
	$query="UPDATE friendslist SET RequestStatus=$sRequest WHERE RequestFrom=$sRequestFrom AND RequestTo=$sRequestTo";
}
mysqli_query($con,$query);
 
 
if($sRequest==1)
{
	echo "<input type='button' class='btn btn-light' value='Following' onclick='return funcUnfollow(this);' data-userID='$sRequestTo'>";
}
if($sRequest==0)
{
	echo "<input type='button' class='btn btn-primary' value='Follow' onclick='return funcFollow(this);' data-userID='$sRequestTo'>";
}
?>