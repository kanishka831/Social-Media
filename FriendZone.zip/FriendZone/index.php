<?php
include("db/connection.php");

if(isset($_POST['btnRegister']))
{

	$email=$_POST['email'];
	$pswd=$_POST['pswd'];
	$query="SELECT * FROM usersinfo WHERE email='$email' AND password='$pswd'";
	$result=mysqli_query($con,$query);
	if(!$result)
	{
		echo "SQL Query Error ".mysqli_error();
	}
	else
	{	
		$row=mysqli_num_rows($result);
		if($row==1)
		{
			$arr=mysqli_fetch_array($result);
			session_start();
			$_SESSION['UserID']=$arr['id'];
			header("Location:home.php");
		}
		else
		{
			$msg="Invalid email and password";
		}
	}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Register</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/login-register.css">
   <style>
	
</style>
</head>
<body>

<div class="bg-image"></div>

<div class="container-fluid">
	<div class="row">
	  <div class='col-sm-4 offset-sm-4 jumbotron div-form-box'>
		   <h3>Login</h3>
		   <form action="index.php" method="post">
		   <div class="form-group">
			  <input type="text" class="form-control" id="email" placeholder="Enter email" name="email" required>
			</div>
			<div class="form-group">
			  <input type="password" class="form-control" id="pswd" placeholder="Enter password" name="pswd" required>
			</div>
			<button type="submit" class="btn btn-primary form-control" id="btnRegister" name='btnRegister'>Login</button>
			<span style='color:red;'><?php 
			if(isset($msg))
			{
				echo $msg;
			}
			?></span>
			<br/><br/>
			<hr>
			Don't have an account?  <a href='register.php'>Sign up</a>
		  </form>
	  </div>
	  
	</div>
	
</div>

</body>
</html>
