<?php
$con=mysqli_connect("localhost","root","","friendzone");
if(!$con)
{
	echo "Connection Error"	.mysqli_connect_error();
}	
		?>

