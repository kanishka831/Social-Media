<script>
$(document).ready(function(){
	$("#UserProfile").click(function()
	{
		window.location.href = "profile.php";
	});
	$("#btnHome").click(function()
	{
		window.location.href = "home.php";
	});
	$("#btnActivity").click(function()
	{
		window.location.href = "Activity.php";
	});
	$("#btnSearch").click(function()
	{
		window.location.href = "SearchUser.php";
	});
	$("#btnChat").click(function()
	{
		window.location.href = "ChatWithFriend.php";
	});
	$("#btnLogout").click(function()
	{
		window.location.href = "logout.php";
	});
	
	
});
</script>

<style>
.footer {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: black;
  text-align: center;
  padding:10px;
}
.fa,.fas{
	font-size: 30px;
}
</style>

<div class='row'>
		<div class='col-sm-4 offset-sm-4'>

			<div class="footer">
			<div class='row'>
			  <div class='col'>
				<i id='btnHome' class="fa fa-home" aria-hidden="true"></i>
			  </div>
			  <div class='col'>
				<i id='btnSearch' class="fa fa-search" aria-hidden="true"></i>
			  </div>
			  <div class='col'>
				<i id='btnChat' class="fas fa-comment-dots"></i>
			  </div>
			  <div class='col'>
				<i id='btnActivity' class="fa fa-heart" aria-hidden="true"></i>
			  </div>
			  <div class='col'>
				<i id='UserProfile' class="fa fa-user" aria-hidden="true"></i>
			  </div>
			  <div class='col'>
				<i id='btnLogout' class="fa fa-times" aria-hidden="true"></i>
			  </div>
			  </div>
			</div>
		</div>
	</div>