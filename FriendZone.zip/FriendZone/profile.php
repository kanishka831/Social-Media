<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <?php
	include("header.php");
 ?>
  
  <style>
	body, html {
	  height: 100%;
	  margin: 0;
	  font-family: Arial, Helvetica, sans-serif;
	}

	* {
	  box-sizing: border-box;
	}

</style>
</head>
<body>
<?php
$query="SELECT * FROM usersinfo WHERE id=".$_SESSION['UserID'];
$result=mysqli_query($con,$query);
$arr=mysqli_fetch_array($result);
$img=$arr['profilePic'];
$query="SELECT PostDir FROM userspost WHERE UserID=".$_SESSION['UserID'];
$result=mysqli_query($con,$query);
$PostCount= mysqli_num_rows($result);

?>
<div class="bg-image"></div>

<div class="container-fluid">
  <div class="row">
		<div class="col-sm-4 offset-sm-4 jumbotron bg-text" style='overflow: scroll;'>
			<div class="row">
				<div class='col' style='text-align: center;'>
					<img src="<?php echo $img; ?>" class="rounded-circle" alt="Cinque Terre" style='width:100%'>
					<a href='upload.php' class="btn btn-primary" style="position: absolute;padding: 0px;border-radius: 17px;width: 24px;top: 60px;left: 90px;">+</a>
					<br/>
					<b><?php echo $arr['username'];?></b>
					
				</div>
				<div class='col' style='text-align:center;'>
					<b><label style='margin-top:30%;'>Post</label></b><br/><?php echo $PostCount;?>
				</div>
				<div class='col' style='text-align:center;'>
					<b><label style='margin-top:30%;'>Following</label></b><br/>200
				</div>
				<div class='col' style='text-align:center;'>
					<b><label style='margin-top:30%;'>Followers</label></b><br/>300
				</div>
			</div>    
			<input type='button' value='Edit Profile' class='form-control' />	
			<hr>
			
			<div class="row">
			<?php
			$query="SELECT * FROM userspost WHERE UserID=".$_SESSION['UserID'];
			$result=mysqli_query($con,$query);
			while($arr= mysqli_fetch_array($result))
			{
			?>
			
				<div class='col'>
					<img src="<?php echo $arr['PostDir'] ?>" class="img-thumbnail" alt="Cinque Terre" style='width:100%; height:150px;'>
				</div>
				

			<?php
			}
			?>
			</div>
		</div>
  </div>
  <?php
		include("footer.php");
  ?>
</div>

</body>
</html>