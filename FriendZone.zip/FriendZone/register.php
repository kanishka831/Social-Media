<?php
include("db/connection.php");

if(isset($_POST['btnRegister']))
{
	$uname=$_POST['uname'];
	$email=$_POST['email'];
	$pswd=$_POST['pswd'];
	$gender=$_POST['gender'];
	$dob=$_POST['dob'];
	
	if($gender=='Male')
	{
		$UserPic='UserProfiles/male.png';
	}
	if($gender=='Female')
	{
		$UserPic='UserProfiles/female.png';
	}
	$query="INSERT INTO usersinfo(username,email,password,dob,gender,profilePic) VALUES('$uname','$email','$pswd','$dob','$gender','$UserPic')";
	$result=mysqli_query($con,$query);
	if(!$result)
	{
		echo "SQL query error ".mysqli_error(); 
	}
	else
	{	
		$msg="Register Successfully";
	}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Register</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/login-register.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="js/jquery-1.12.4.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script>
  $(function() {
    $(".datepickerr").datepicker({
		dateFormat:"yy-mm-dd",
		changeMonth: true,
		changeYear: true
	});
  });
  $(document).ready(function()
  {
	  $("#btnRegister").click(function()
	  {
		 var pwd=$("#pswd").val();
		 var cpwd=$("#cpswd").val();
		 if(pwd!=cpwd)
		 {
			 $("#cpwdMsg").text("Password doesn't match");
			 return false;
		 }
	  });
	 
  });
  </script>
  
   <style>
	
</style>
</head>
<body>

<div class="bg-image"></div>

<div class="container-fluid">
	<div class="row">
	  <div class='col-sm-4 offset-sm-4 jumbotron div-form-box'>
		   <h3>Sign Up</h3>
		   <form action="register.php" method="post">
		   <div class="form-group">
			  <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" required>
			</div>
			<div class="form-group">
			  <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
			</div>
			<div class="form-group">
			  <input type="password" class="form-control" id="pswd" placeholder="Enter password" name="pswd" required>
			</div>
			<div class="form-group">
			  <input type="password" class="form-control" id="cpswd" placeholder="Enter confirm password" name="cpswd" required>
			  <span id="cpwdMsg" style='color:red;'></span>
			</div>
			<div class="form-group">
				<div class="form-check-inline">
				  <label class="form-check-label">
					<input type="radio" class="form-check-input" name="gender" required value='Male'>Male
				  </label>
				</div>
				<div class="form-check-inline">
				  <label class="form-check-label">
					<input type="radio" class="form-check-input" name="gender" value='Female'>Female
				  </label>
				</div>
			</div>
			<div class="form-group">
			  <input type="text" class="form-control datepickerr" id="datepicker" id="pwd" placeholder="Enter date of birth" name="dob" required>
			</div>
			
			<button type="submit" class="btn btn-primary form-control" id="btnRegister" name='btnRegister'>Sign Up</button>
			<span style='color:green;'><?php 
			if(isset($msg))
			{
				echo $msg;
			}
			?></span>
			<br/><br/><br/>
			Have an account? <a href='index.php'>Log in</a>
		  </form>
	  </div>
	  
	</div>
	
</div>

</body>
</html>
