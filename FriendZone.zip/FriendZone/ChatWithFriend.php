

<html>
<title>User Profile</title>
<head>
<?php
include("header.php");
?>
<script>
$(document).ready(function(){
  $("#inputSearch").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#usersTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
	
  });
  
  $("#usersTable tr").click(function()
  {
	  var userid=$(this).attr("data-userid");
	  window.location.replace("chat.php?UserTo="+userid);
  });
});
</script>
<body>



<div class="bg-image"></div>
<div class='container-fluid'>
	<div class='row'>
		<div class='col-sm-4 offset-sm-4 jumbotron bg-text' style='overflow: scroll;'>
			<input type='text' placeholder='Search...' id='inputSearch' class='form-control'>
			<table id='usersTable'  class='table table-sm table-hover' >
			<?php
			$query="SELECT * FROM usersinfo where id!=".$_SESSION['UserID'];
			$result=mysqli_query($con,$query);
			while($arr=mysqli_fetch_array($result))
			{
				echo "<tr data-userid='".$arr['id']."'>
						<td><img src='".$arr['profilePic']."' class='rounded-circle' style='width:60px;height:60px;'>  ".$arr['username']."</td>
					</tr>";
			}
			?>
			</table>
		</div>
	</div>

	<?php
		include("footer.php");
	?>
</div>


</body>
</html>

