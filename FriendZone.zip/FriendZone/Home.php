<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
	include("header.php");
 ?>
 
  
  <style>
	.bg-image {
	  /* The image used */
	  background-image: url("https://www.w3schools.com/howto/photographer.jpg");
	  
	  /* Add the blur effect */
	  filter: blur(8px);
	  -webkit-filter: blur(8px);
	  
	  /* Full height */
	  height: 100%; 
	  
	  /* Center and scale the image nicely */
	  background-position: center;
	  background-repeat: no-repeat;
	  background-size: cover;
	}

	/* Position text in the middle of the page/image */
	.bg-text {
	  position: absolute;
	  top: 0%;	
	  height:100%;
	}
	
.post-box
{
	width:100%;
	border:1px solid;
}
.user-detail{
	height:50px;
	border:1px solid;
}
.user-post
{
	width:100%;
	height:300px;
}
.user-reaction{
	height:50px;
	padding:10px;
}
</style>
</head>
<body>

<div class="bg-image"></div>

<div class="container-fluid">
  <div class="row">
		<div class="col-sm-4 offset-sm-4 jumbotron bg-text" style='overflow: scroll;'>
		<?php
			$query="SELECT ui.username,ui.profilePic,up.PostDir FROM usersinfo ui INNER JOIN userspost up on up.UserID=ui.id ORDER BY up.id DESC";
			$result=mysqli_query($con,$query);
			while($arr= mysqli_fetch_array($result))
			{
		?>
		
			<div class='post-box'>
				<div class='user-detail'>
					<img src="<?php echo $arr['profilePic'];?>" class="rounded-circle" alt="No Image Found" style='width:45px'>
					<?php echo $arr['username'];?>
				</div>
				<div class='user-post'>
					<img src="<?php echo $arr['PostDir'];?>" style='width:100%;height:100%;'>
				</div>
				<div class='user-reaction'>
					<i id='btnLike' class="fa fa-heart-o"></i>
					<i id='btnLike' class="fa fa-comment-o"></i>
					<i id='btnLike' class="fa fa-paper-plane-o"></i>
				</div>
			</div>
			
			<?php
			}
		?>
		</div>
  </div>

  <?php
  include("footer.php");
  ?>
  
</div>

</body>
</html>