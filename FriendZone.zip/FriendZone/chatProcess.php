<?php
include("db/connection.php");
session_start();
$sReceiver= $_GET['sReceiver'];
$sSender = $_SESSION['UserID'];


if($_GET['sMessageRequest']=="SendMessage")
{
	$sMessage= $_GET['sMessage'];
	$date=date("Y-m-d H:i:s");
	$query="INSERT INTO message(sender,receiver,message,mDate)
	VALUES($sSender,$sReceiver,'$sMessage','$date')";

	if(!mysqli_query($con,$query))
	{
		echo mysqli_error();
	}
}

if($_GET['sMessageRequest']=="GetMessage")
{
	$query="SELECT * FROM message WHERE (sender=$sSender and receiver=$sReceiver) or (sender=$sReceiver and receiver=$sSender)";
	$result=mysqli_query($con,$query);
	while($rowFetch=mysqli_fetch_array($result))
	{
		if($rowFetch['sender']==$_SESSION['UserID'])
		{
			echo "<div class='container darker'>
				  <p class='text-right'>".$rowFetch['message']."</p>
				  <span class='time-left'>".$rowFetch['mDate']."</span>
				</div>";
		}
		else
		{
			echo "<div class='container'>
			  <p>".$rowFetch['message']."</p>
			  <span class='time-right'>".$rowFetch['mDate']."</span>
			</div>";
		}
	}
}

	
 

?>