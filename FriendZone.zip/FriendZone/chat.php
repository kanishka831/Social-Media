<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php
	include("header.php");
 ?>
 
 <style>
 
 /* Chat containers */
.container {
  border: 2px solid #dedede;
  background-color: #f1f1f1;
  border-radius: 5px;
  padding: 10px;
  margin: 10px 0;
}

/* Darker chat container */
.darker {
  border-color: #ccc;
  background-color: #ddd;
}

/* Clear floats */
.container::after {
  content: "";
  clear: both;
  display: table;
}

/* Style images */
.container img {
  float: left;
  max-width: 60px;
  width: 100%;
  margin-right: 20px;
  border-radius: 50%;
}

/* Style the right image */
.container img.right {
  float: right;
  margin-left: 20px;
  margin-right:0;
}

/* Style time text */
.time-right {
  float: right;
  color: #aaa;
}

/* Style time text */
.time-left {
  float: left;
  color: #999;
}
 
 .sendMessage {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  text-align: center;
  padding:10px;
}

 </style>
 
 <script>
 $(document).ready(function(){
	setInterval(getMessage, 3000);
	$("#btnSendMessage").click(function(){
		sendMessage();
	});
 });
 
 function sendMessage()
 {
	var Message=$('#txtMessage').val();
	var UserTo =<?php echo $_GET['UserTo'];?>;
	$('#txtMessage').val("");
	$.get("chatProcess.php", {sReceiver: UserTo,sMessage: Message,sMessageRequest: "SendMessage"}, function(result){
		//alert(result);
		getMessage();
	});
	
 }
 
 function getMessage(){
	var UserTo =<?php echo $_GET['UserTo'];?>;
	$.get("chatProcess.php", {sReceiver: UserTo,sMessageRequest: "GetMessage"}, function(result){
		$(".message-box").html(result);
	});
 }
 </script>
</head>
<body>

<div class="bg-image"></div>

<div class="container-fluid">
  <div class="row">
		<div class="col-sm-4 offset-sm-4 jumbotron bg-text" style='overflow: scroll;'>
			<?php
			$query="SELECT * FROM usersinfo where id=".$_GET['UserTo'];
			$result=mysqli_query($con,$query);
			while($rowFetch=mysqli_fetch_array($result))
			{
				echo "<div class='user-detail'>
					<img src='".$rowFetch['profilePic']."' class='rounded-circle' alt='No Image Found' style='width:45px'>
					".$rowFetch['username']."</div>";
			}
			?>
			<div class='message-box'>
			
				
				
			</div>
		</div>
  </div>
  <div class='row'>
		<div class='col-sm-4 offset-sm-4'>
			<div class="sendMessage">
				<div class="input-group">
				  <input type="text" class="form-control" id="txtMessage" placeholder="Enter Message Here">
				  <div class="input-group-append">
					<button class="btn-primary" id='btnSendMessage'><i class="fa fa-paper-plane-o"></i></button>
				  </div>
				</div>
			</div>
		</div>
	</div>
  
</div>

</body>
</html>