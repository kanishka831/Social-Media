<?php
include("db/connection.php");
session_start();
if(!isset($_SESSION['UserID']))
{
	header("Location:index.php");
}
?>  
  
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

<style>
	body, html {
	  height: 100%;
	  margin: 0;
	  font-family: Arial, Helvetica, sans-serif;
	}

	* {
	  box-sizing: border-box;
	}

	.bg-image {
	  /* The image used */
	  background-image: url("https://www.w3schools.com/howto/photographer.jpg");
	  
	  /* Add the blur effect */
	  filter: blur(8px);
	  -webkit-filter: blur(8px);
	  
	  /* Full height */
	  height: 100%; 
	  
	  /* Center and scale the image nicely */
	  background-position: center;
	  background-repeat: no-repeat;
	  background-size: cover;
	}

	/* Position text in the middle of the page/image */
	.bg-text {
	  position: absolute;
	  top: 0%;	
	  height:100%;
	}
	
	.footer {
   position: absolute;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   padding:5px;
   text-align: center;
}
.fa{
font-size:30px;
}
</style>